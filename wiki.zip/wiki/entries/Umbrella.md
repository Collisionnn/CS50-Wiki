# a bold umbrella
a*spaced*umbrella